# Document structures

Use these exact headings and order by default. Use an explicitly supplied organizational template when requested. Keep unknowns as TBD, identify proposed values, and explain any inapplicable section briefly. Put supporting material in unnumbered appendices.

## Business Requirements Document

1. **Document Control & Metadata** — Document ID, title, version, date, author/project lead, status, sources, and revision history with date, author, and changes.
2. **Executive Summary** — Three to four bullets summarizing the initiative, business rationale, and desired outcome.
3. **Business Objectives & Goals** — Problem or opportunity, SMART objectives, and KPIs with metric definition, baseline, target, measurement window, source, and owner. Mark unconfirmed targets proposed or TBD.
4. **Project Scope** — In-scope features, workflows, and deliverables. Explicit out-of-scope and deferred work.
5. **Stakeholder & RACI Matrix** — Sponsor, Business Analyst, Project Manager, SMEs, End Users, and other applicable roles. Map activities or decisions to Responsible, Accountable, Consulted, and Informed. Use one accountable role per row where known. Label proposed assignments.
6. **Business Process Overview (As-Is vs. To-Be)** — Current process and evidence of bottlenecks or manual errors, future workflow and handoffs, and any supplied design or process diagrams. Mark new wireframes as pending PRD discovery.
7. **High-Level Requirements** — List business requirements, stakeholder/user requirements, high-level functional requirements, and high-level non-functional requirements. Give each an ID and link it to the relevant objective, feature, and parent requirement. Keep detailed system behavior and acceptance criteria in the PRD. Reuse an ID when the PRD elaborates the same requirement. Assign child IDs when a high-level requirement splits into multiple behaviors.
8. **Assumptions, Constraints & Dependencies** — Separate each category. State the impact, validation action, and owner role where known. Capture business risks here as needed.
9. **Cost-Benefit Analysis & Financials** — Show development, licensing, training, and maintenance costs, plus expected savings, revenue, or time benefits. State time horizon, currency, and evidence if supplied. Leave unknown costs or benefits TBD. Calculate ROI only from defensible inputs and show the formula and period.
10. **Approvals & Sign-Off** — Provide a table with name, title/role, status, signature, and date. Leave signatures and dates blank or pending until provided. Include the business acceptance conditions that reviewers should assess.

## Product Requirements Document

1. **Metadata & Control Header** — Product or feature title, owner, status, version, version history, source BRD version, and Design, Engineering, QA, Marketing, and other relevant stakeholders.
2. **Overview & Context** — Customer problem, why it matters now, strategic alignment, target audience, and personas.
3. **Goals & Success Metrics** — Objectives, metric definition, baseline, proposed or confirmed target, window, source, and measurement owner. Identify analytics events and measurement gaps where relevant.
4. **Scope (What’s In and What’s Out)** — MVP feature IDs and release boundaries. Name deferred capabilities and dependencies that determine sequencing.
5. **User Scenarios & Critical User Journeys (CUJs)** — User stories with persona, action, and benefit. Map triggers, preconditions, happy paths, alternate paths, and completion outcomes. Address applicable error, empty, offline, validation, and permission states.
6. **Functional & Non-Functional Requirements** — Detail observable system behavior, rules, data, integrations, and recovery. Use MoSCoW or P0–P2 consistently. Include measurable or explicitly TBD NFRs for relevant areas such as performance, privacy, security, scalability, accessibility, and localization. Link each requirement to its feature, business requirement, and acceptance criteria or verification method. Use Given/When/Then where helpful.
7. **Design & Assets** — Embed or link wireframes, mockups, user flows, and prototypes. Include a design index with ID, screen/flow, linked feature and requirements, state, and design status. Provide proposed microcopy, errors, and notifications where they affect behavior. For workflows without screens, use a process or sequence diagram.
8. **Dependencies, Assumptions & Risks** — Capture APIs, teams, services, constraints, risk impact, mitigation, and owner role. Include rollout, migration, and fallback considerations where material.
9. **Open Questions & Decision Log** — For questions, record ID, impact, owner role, and whether they block delivery. For decisions, record date, decision, rationale, impacted IDs, and status. Mark stakeholder approval as pending unless evidenced.

## Traceability appendix

Use these columns: Objective | BR ID | Stakeholder Requirement ID | Epic ID | Feature ID | FR/NFR ID | AC or verification ID | Wireframe ID | MVP/later | Status.

Record many-to-many relationships explicitly. Explain deferred requirements, shared NFRs, and business-only work. Use stable IDs, such as SR-001 for stakeholder requirements and WF-001 for wireframes.
