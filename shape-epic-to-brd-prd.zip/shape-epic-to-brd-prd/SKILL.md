---
name: shape-epic-to-brd-prd
description: 'Run the Epic Docs workflow: clarify a product epic, break it into MVP features, and deliver a linked BRD, PRD, and wireframes together. Trigger when the user says Epic Docs or asks for this combined product requirements workflow.'
---

# Shape an Epic into Features, BRD, and PRD

Turn an idea into an actionable feature breakdown, establish the business requirements, then derive the product requirements. Preserve a clear chain from business need to testable behavior. Support the complete workflow or only the stage the user requests.

## Start with Epic Docs

Treat **Epic Docs** as a request for the full workflow. Use the epic already described in the conversation or supplied as an attachment. If there is no epic, ask for the idea, who it serves, and the outcome in one message. The short phrase is a natural-language trigger after installation. Also support explicit invocation using the platform's native skill selector.

## Establish context

Read supplied briefs, research, requirements, and templates before asking questions. Identify the problem, target users, desired outcomes, current workflow, constraints, and scope. If key information is missing, ask up to five targeted questions in one message before drafting. Prioritize questions that affect MVP scope, business rules, user journeys, or design. Skip questions answered by the source material or that can safely be deferred. Accept partial answers and proceed with labeled assumptions. If the user asks for an immediate draft, proceed with reasonable assumptions and note unresolved questions.

Separate confirmed facts, proposed choices, assumptions, and open questions. Do not invent research, metrics, budgets, commitments, legal obligations, approvals, or technical capabilities. Label suggested targets as proposals and unknown values as TBD. If the idea is sparse, produce a provisional draft with visible assumptions rather than presenting it as implementation-ready.

Follow an organization-provided template when available, preserving the content and traceability described here. Use neutral terminology unless a product or domain is supplied.

## Decompose the idea

1. State the problem, user, outcome, and epic boundary in a short epic brief. Separate requested solutions from the underlying need.
2. Map the main user journey and identify capabilities needed to complete it.
3. Split capabilities into independently understandable, demonstrable, testable features. Prefer vertical slices that deliver user value; keep infrastructure enablers separate and link them to the features they enable. Avoid splitting only into UI, API, and database work.
4. For each feature, record ID, short name, user/problem, value, concise behavior, boundaries, proposed priority with rationale, dependencies, acceptance outline, and MVP/later disposition. Use relative size only when useful and mark it provisional; do not fabricate story points, delivery dates, or team capacity.
5. Split oversized features by workflow step, user segment, business-rule variation, or smallest useful happy path plus necessary failure handling. Do not force an arbitrary feature count.
6. Propose the smallest coherent end-to-end MVP, including essential permissions, failure handling, and enabling dependencies. Explain deferred scope and tradeoffs. Use MoSCoW by default; use RICE only when credible inputs exist.

Present the feature map as a table. Expand selected features into user stories when that makes implementation clearer; do not confuse features with engineering tasks.

## Draft the BRD, then the PRD

Read [references/document-structures.md](references/document-structures.md) for the relevant document structure. Create the BRD around business outcomes, processes, scope, rules, and business acceptance. Derive the PRD from that BRD and the selected features, describing product behavior, interactions, data, and verifiable acceptance criteria. Avoid duplicating the BRD as the PRD.

After intake, complete the feature breakdown, BRD, PRD, wireframes or equivalent flows, and traceability in the same delivery turn. Derive them in that order internally. Deliver all together even when they are separate files. Do not pause between outputs, ask whether to proceed, or deliver only a feature list with the documents promised later. Honor checkpoints or a partial workflow when explicitly requested. Carry unresolved BRD decisions into the PRD as explicit assumptions or blockers. Never imply stakeholder approval from the act of drafting.

## Include wireframes

Use supplied design links or images and identify their status. For a user-facing MVP without designs, create low-fidelity wireframes for its critical screens and flows. Include them in PRD section 7 and cross-reference them from BRD section 6. Label each concept with an ID, linked feature and requirement IDs, screen purpose, primary action, navigation, and relevant loading, empty, error, or permission states. Use editable sketches or embedded images when supported. Otherwise include a compact screen layout and state table. For an API or operational workflow without a UI, include a process or sequence diagram in the same slot. Mark new designs Proposed and leave missing external links as TBD.

Use stable IDs: E-001 for epics, F-001 for features, BR-001 for business requirements, FR-001 for functional requirements, NFR-001 for nonfunctional requirements, and AC-001 for acceptance criteria. Preserve existing IDs on updates; never renumber merely for presentation. Link multiple requirements where appropriate, and mark intentionally deferred or non-product business requirements explicitly.

Write requirements as single, unambiguous statements. Include actor, trigger, observable behavior, and relevant conditions. Give each functional requirement testable criteria, including meaningful negative cases. Specify measurable nonfunctional thresholds only when confirmed or clearly proposed. Avoid terms such as fast, seamless, or secure without an operational definition.

## Check consistency and deliver

- Verify every in-scope feature maps to business requirements and product requirements; verify functional requirements map to acceptance criteria.
- Check for conflicting scope, missing dependencies, orphan requirements, duplicate features, and requirements disguised as assumptions.
- Check relevant empty/error states, permissions, alternate flows, data lifecycle, accessibility, analytics, and rollout needs. Scale depth to the product; explain genuinely inapplicable sections briefly.
- List unresolved decisions with impact and suggested owner role; distinguish blockers from nonblocking questions. Use role placeholders when owners are unknown.
- Label documents Draft unless approval is evidenced. Include version, date, source inputs, and a concise revision history. For changes, update the feature map, BRD, PRD, and traceability together and summarize affected IDs.

Deliver the feature breakdown, BRD, PRD, and a traceability matrix as requested. For the complete workflow, default to two separate editable documents with the feature breakdown and matrix included as appendices. Use available document/file creation capabilities and the environment's saving requirements; if files cannot be created, provide clearly separated copy-ready content and explain the limitation. Do not create Jira issues, publish documents, or message stakeholders unless requested.

End with a brief statement of readiness and the most consequential unresolved decisions. Do not call a draft approved or engineering-ready while material behavior remains undefined.
