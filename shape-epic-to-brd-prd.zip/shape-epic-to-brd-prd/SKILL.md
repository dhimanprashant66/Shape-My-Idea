---
name: shape-epic-to-brd-prd
description: 'Run Shape My Idea: interview the user about a product idea, propose an MVP feature breakdown, then draft a linked BRD and PRD with separate user confirmations. Trigger on Shape My Idea or requests for guided epic discovery and requirements.'
---

# Shape My Idea

Turn an idea into an actionable feature breakdown, then offer the BRD and PRD as separate decisions. Preserve a clear chain from business need to testable behavior.

## Start with Shape My Idea

Treat **Shape My Idea** (case-insensitive, with or without trailing punctuation) as a request to start discovery. Use the epic already described in the conversation or supplied as an attachment. If there is no epic, ask for the idea, who it serves, and the outcome in one message. Also support invocation through the platform's native skill selector. An initial request mentioning all deliverables does not skip the separate confirmations.

## Establish context

Read supplied briefs, research, requirements, and templates before asking questions. With a bare idea, start the interview and wait for answers before proposing features. Ask up to five targeted questions per round. Follow the answers with focused challenges where they expose conflicts or material gaps. Ask who experiences the problem, how they handle it now, what evidence supports it, what outcome would count as success, and what trade-offs or constraints shape the MVP. Probe concrete examples and exceptions. Challenge unsupported solution choices and competing priorities respectfully, explaining why a consequential answer matters. Skip questions already answered.

Before moving on, check that the current stage has enough evidence to be useful. If a material gap remains, ask a follow-up. If the user cannot answer, state what it affects and ask whether to proceed with that specific assumption or leave it open. Do not repeat resolved questions or force rounds when the supplied evidence is sufficient. An assumption may support a draft, but it does not constitute a confirmed requirement.

Separate confirmed facts, proposed choices, assumptions, and open questions. Do not invent research, metrics, budgets, commitments, legal obligations, approvals, or technical capabilities. Label suggested targets as proposals and unknown values as TBD.

Follow an organization-provided template when available, preserving the content and traceability described here. Use neutral terminology unless a product or domain is supplied.

## Present discovery as a questionnaire

- Use the host's native questionnaire or choice controls when exposed. Check the actual available capabilities before choosing a control. A Markdown list is a text fallback and must not be described as clickable.
- Ask one decision per question. Use single-select for mutually exclusive choices, such as the launch region or booking model. Use multi-select for independent choices, such as comparison criteria, when the host supports it. Include concise, context-specific options and make the selection rule clear.
- Offer **Other** with a free-text field when available and when the listed options may be incomplete. Use the host's built-in Other field where provided, without adding a duplicate. Otherwise ask for the detail in a follow-up when Other is selected. Offer **Not sure yet** where uncertainty is valid. Treat it as an open decision rather than agreement.
- Use a short text field or a focused follow-up for answers that need original details, such as exact routes, partner names, evidence, or a numeric KPI target. Use choices to establish direction before requesting those details.
- If the host supports only single-select controls, keep exclusive questions clickable. For multi-select questions, use lettered choices and let the user reply with all applicable letters, or use individual Yes/No controls if that reduces effort. If the host has no interactive controls, show a compact lettered menu with a sample reply such as `1B, 2A+C, 3 Other: regional operators`.
- Use native single-select controls for the BRD and PRD confirmation questions where available, with **Create BRD/PRD** and **Stop here** as the corresponding choices. Keep each gate separate and wait for an explicit selection. Use the existing yes/no question as the text fallback.

For example, ask **Who is the primary MVP audience?** as a single-select question with relevant audience options. Ask **Which criteria should users compare?** as a multi-select question with options such as Price, Journey duration, Departure time, and Seat availability. Ask separately about the launch region, named operators, and whether booking happens in-app or via a redirect when those decisions matter.

## Decompose the idea

1. State the problem, user, outcome, and epic boundary in a short epic brief. Separate requested solutions from the underlying need.
2. Map the main user journey and identify capabilities needed to complete it.
3. Split capabilities into independently understandable, demonstrable, testable features. Prefer vertical slices that deliver user value; keep infrastructure enablers separate and link them to the features they enable. Avoid splitting only into UI, API, and database work.
4. For each feature, record ID, short name, user/problem, value, concise behavior, boundaries, proposed priority with rationale, dependencies, acceptance outline, and MVP/later disposition. Use relative size only when useful and mark it provisional; do not fabricate story points, delivery dates, or team capacity.
5. Split oversized features by workflow step, user segment, business-rule variation, or smallest useful happy path plus necessary failure handling. Do not force an arbitrary feature count.
6. Propose the smallest coherent end-to-end MVP, including essential permissions, failure handling, and enabling dependencies. Explain deferred scope and tradeoffs. Use MoSCoW by default; use RICE only when credible inputs exist.

Present the feature map as a table. Expand selected features into user stories when that makes implementation clearer; do not confuse features with engineering tasks.

## Deliver one stage at a time

1. **Features:** After discovery, deliver only the proposed feature list and MVP recommendation, with material assumptions or trade-offs. Ask: **Would you like me to create the BRD from this feature breakdown?** Stop and wait. If the user requests revisions, revise the feature list and ask again.
2. **BRD:** Start only after the user explicitly requests the BRD or says yes to the BRD question after seeing the feature list. Clarify remaining business rules, objectives, process, roles, constraints, or financial assumptions where material. Deliver only the BRD, then ask: **Would you like me to create the PRD from this BRD?** Stop and wait. If the user requests BRD revisions, update the BRD and ask again.
3. **PRD:** Start only after the user explicitly requests the PRD or says yes to the PRD question after seeing the BRD. Resolve material questions about journeys, permissions, data, error states, or release boundaries. Deliver the PRD with wireframes or process flows and the traceability appendix.

Apply each yes only to the stage just offered. If the user declines, stop. If their reply is ambiguous, clarify before moving forward. During a clarification round, keep the current stage active and do not ask for approval of a future stage. User permission to draft does not imply stakeholder sign-off.

Read [references/document-structures.md](references/document-structures.md) for the relevant document structure. Base the BRD on the latest agreed feature scope and the PRD on the latest BRD. Carry unresolved BRD decisions into the PRD as explicit assumptions or blockers. Record material scope changes for review rather than silently changing the business baseline.

## Include wireframes

At the BRD stage, link any supplied designs or process diagrams in section 6 and identify their status. If designs are unavailable, record that they are pending PRD discovery. At the PRD stage, use supplied designs or create low-fidelity wireframes for critical user-facing MVP screens and flows in section 7. Link to the relevant BRD process and requirements. Label each concept with an ID, linked feature and requirement IDs, screen purpose, primary action, navigation, and relevant loading, empty, error, or permission states. Use editable sketches or embedded images when supported. Otherwise include a compact screen layout and state table. For a workflow without a UI, include a process or sequence diagram. Mark new designs Proposed.

Use stable IDs: E-001 for epics, F-001 for features, BR-001 for business requirements, FR-001 for functional requirements, NFR-001 for nonfunctional requirements, and AC-001 for acceptance criteria. Preserve existing IDs on updates; never renumber merely for presentation. Link multiple requirements where appropriate, and mark intentionally deferred or non-product business requirements explicitly.

Write requirements as single, unambiguous statements. Include actor, trigger, observable behavior, and relevant conditions. Give each functional requirement testable criteria, including meaningful negative cases. Specify measurable nonfunctional thresholds only when confirmed or clearly proposed. Avoid terms such as fast, seamless, or secure without an operational definition.

## Check consistency and deliver

- In the BRD, verify in-scope features map to business requirements. In the PRD, verify those mappings extend to product requirements and acceptance criteria.
- Check for conflicting scope, missing dependencies, orphan requirements, duplicate features, and requirements disguised as assumptions.
- Check relevant empty/error states, permissions, alternate flows, data lifecycle, accessibility, analytics, and rollout needs. Scale depth to the product; explain genuinely inapplicable sections briefly.
- List unresolved decisions with impact and suggested owner role; distinguish blockers from nonblocking questions. Use role placeholders when owners are unknown.
- Label documents Draft unless approval is evidenced. Include version, date, source inputs, and a concise revision history. For changes, summarize affected IDs and flag any previously delivered document that needs revision. Revise only the deliverables requested.

For each requested document, use available file creation capabilities to deliver a separate editable document. If file creation is unavailable, provide copy-ready content and explain the limitation. Do not create Jira issues, publish documents, or message stakeholders unless requested.

Summarize material unresolved decisions and readiness before the stage's closing question. Do not call a draft approved or engineering-ready while material behavior remains undefined.
